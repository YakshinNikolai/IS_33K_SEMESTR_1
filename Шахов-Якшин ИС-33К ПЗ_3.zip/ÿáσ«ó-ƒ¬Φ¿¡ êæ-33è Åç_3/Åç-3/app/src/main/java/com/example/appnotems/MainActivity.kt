package com.example.appnotems

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.toString

class MainActivity : AppCompatActivity() {

    private lateinit var databaseHelper: NotesDatabaseHelper
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: NotesAdapter
    private var notes = mutableListOf<Note>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        databaseHelper = NotesDatabaseHelper(this)


        recyclerView = findViewById(R.id.recyclerViewNotes)
        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = NotesAdapter(
            notes = notes,
            onNoteClick = { note -> showNoteDialog(note) },
            onNoteLongClick = { note -> deleteNote(note) }
        )

        recyclerView.adapter = adapter


        loadNotes()


        findViewById<View>(R.id.button4).setOnClickListener {
            showNoteDialog()
        }
    }

    private fun loadNotes() {
        notes.clear()
        notes.addAll(databaseHelper.getAllNotes())
        adapter.updateNotes(notes)
    }

    private fun showNoteDialog(note: Note? = null) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_note, null)
        val etTitle = dialogView.findViewById<EditText>(R.id.etNoteTitle)
        val etContent = dialogView.findViewById<EditText>(R.id.etNoteContent)

        val isEdit = note != null
        if (isEdit) {
            etTitle.setText(note?.title)
            etContent.setText(note?.content)
        }

        AlertDialog.Builder(this)
            .setTitle(if (isEdit) "Редактировать заметку" else "Новая заметка")
            .setView(dialogView)
            .setPositiveButton("Сохранить") { _, _ ->
                val title = etTitle.text.toString()
                val content = etContent.text.toString()

                if (title.isNotEmpty() && content.isNotEmpty()) {
                    if (isEdit) {
                        // Обновление существующей заметки
                        val updatedNote = note!!.copy(title = title, content = content)
                        databaseHelper.updateNote(updatedNote)
                    } else {
                        // Создание новой заметки
                        val newNote = Note(title = title, content = content)
                        databaseHelper.addNote(newNote)
                    }
                    loadNotes()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun deleteNote(note: Note) {
        AlertDialog.Builder(this)
            .setTitle("Удаление заметки")
            .setMessage("Вы уверены, что хотите удалить эту заметку?")
            .setPositiveButton("Удалить") { _, _ ->
                databaseHelper.deleteNote(note.id)
                loadNotes()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }
}